from odoo import models, fields



class sahabat(models.Model):


    _name = "sahabat.database"
    name = fields.Char(string="name", required=True)
    image = fields.Binary()
 
    
               
  








